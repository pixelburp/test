# Pixel Platformer
A simple platformer game that demostrates the power of the Entity game engine. This uses version 0.2.1 of Entity.

## Running
All code is compiled into a single file, entity.min.js. To run debug.min.js you must download the source of EntityJS. [Here](https://github.com/bendangelo/EntityJS)